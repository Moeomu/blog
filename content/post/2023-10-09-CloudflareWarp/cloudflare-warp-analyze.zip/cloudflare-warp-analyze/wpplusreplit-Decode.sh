#!/bin/bash
echo
echo "请稍等，下载更新中……"
rm -rf warpplus.sh
wget -N https://gitlab.com/rwkgyg/CFwarp/-/raw/main/point/warpplus.sh >/dev/null 2>&1
chmod +x warpplus.sh
./warpplus.sh
